
<?php $__env->startSection('title','Message'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.message.inc.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card">
           
              <div class="card-header">
                <h3 class="card-title">All Messages</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
              <table class="table">
              <thead class="thead-light">
                  <?php
                      $i =1;
                  ?>
                <tr>
                  <th scope="col"><?php echo e($i++); ?></th>
                  <th scope="col">Name</th>
                  <th scope="col">New massage</th>
                  <th class="text-right">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
                    $i = 1;
                ?>

                
                   <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <tr>
                        <th scope="row"><?php echo e($i++); ?></th>
                        <td><?php echo e($item->senders['name']); ?></td>
                        <td><?php echo e($item->message); ?></td>
                      <td class="text-right">
                      
                      <a href="#" class="btn btn-sm btn-primary replyBtn" data-recipent="<?php echo e($item->sender); ?>">Reply</a>
                      </td>
                    </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                   
                
                    
              </tbody>
            </table>
              </div>
              <!-- /.card-body -->
              
            </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
    $(function () {
        $("#reply").hide();
        $(".replyBtn").click(function (e){
            e.preventDefault();
            $("#reply").show();
            var recipent = $(this).data('recipent');
            
            $("#reply [name = recipent]").val(recipent);
            
        });
    
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\babycare\resources\views/admin/message/message.blade.php ENDPATH**/ ?>