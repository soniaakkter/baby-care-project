

<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('content'); ?>

    <div class="section profile-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <form action="#" method="POST">

                        <img style="border-radius: 50%;"
                             height="200"
                             width="200"
                             src="<?php echo e(\Illuminate\Support\Facades\Auth::user()->image == null ?
                                asset('images/clients/01.jpg') :
                                asset('images/'.\Illuminate\Support\Facades\Auth::user()->image)); ?>"
                             alt="Avatar">

                        <div class="form-group">
                            <label for="exampleInputName">Name</label>
                            <input
                                    type="name"
                                    class="form-control"
                                    id="exampleInputName"
                                    disabled
                                    value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?>"
                            />
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail">Email address</label>
                            <input
                                    type="email"
                                    class="form-control"
                                    id="exampleInputEmail"
                                    aria-describedby="emailHelp"
                                    disabled
                                    value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->email); ?>"
                            />
                            <small id="emailHelp" class="form-text text-muted"
                            >We'll never share your email with anyone else.</small
                            >
                        </div>
                        <a href="<?php echo e(url('/admin/edit/'.\Illuminate\Support\Facades\Auth::id())); ?>"
                           class="btn btn-primary">Edit</a>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\babycare\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>