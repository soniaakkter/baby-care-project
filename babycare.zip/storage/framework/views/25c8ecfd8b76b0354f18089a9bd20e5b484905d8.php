<div class="row">
    <div class="col-md-2"></div>
<div class="card col-md-8" id="reply">
    <form role="form" method="POST" action="<?php echo e(action('AdminMessageController@message_reply')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="recipent">
        <div class="card-body">
          <div class="form-group">
            <label for="exampleInputEmail1">Reply customer message</label>
            <input type="text" class="form-control" name="message" placeholder="Enter your reply" required>
          </div>
            <button type="submit" class="btn btn-primary">Send</button>   
        </div>
    </form>
</div>
</div><?php /**PATH C:\xampp\htdocs\babycare\resources\views/admin/message/inc/form.blade.php ENDPATH**/ ?>