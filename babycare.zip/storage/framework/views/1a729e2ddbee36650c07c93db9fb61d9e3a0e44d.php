

<?php $__env->startSection('title',$user->name); ?>

<?php $__env->startSection('content'); ?>
    <div class="section profile-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <form class="form" action="<?php echo e(url('/admin/update/'.$user->id)); ?>"
                          method="POST"
                          enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <img style="border-radius: 50%;"
                             height="200"
                             width="200"
                             src="<?php echo e($user->image == null ? asset('images/clients/01.jpg') : asset('images/'.$user->image)); ?>"
                             alt="Avatar">

                        <div class="form-group">
                            <label for="exampleInputName">Name</label>
                            <input
                                    name="name"
                                    type="text"
                                    class="form-control"
                                    id="exampleInputName"
                                    value="<?php echo e($user->name); ?>"
                            />
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail">Email address</label>
                            <input
                                    type="email"
                                    name="email"
                                    class="form-control"
                                    id="exampleInputEmail"
                                    aria-describedby="emailHelp"
                                    value="<?php echo e($user->email); ?>"
                            />
                            <small id="emailHelp" class="form-text text-muted"
                            >We'll never share your email with anyone else.</small
                            >
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlFile1">Change picture</label>
                            <input
                                    type="file"
                                    name="photo"
                                    class="form-control-file"
                                    id="exampleFormControlFile1"
                            />
                        </div>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\babycare\resources\views/admin/profile/edit.blade.php ENDPATH**/ ?>